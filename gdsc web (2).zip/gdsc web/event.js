function myFunction2() {
    document.getElementById('eventback').style.backgroundImage="url(images/eventblack.png)"; 
    document.body.style.backgroundColor = "#404040";// specify the image path here
    document.getElementById('b1').style.backgroundColor="#404040"; 
    document.getElementById('footer1').style.backgroundColor="#404040"; 
    document.getElementById("c1").src = "images/logo2.png";
    document.getElementById('d1').style.color="white"; 
    document.getElementById("home1").style.color = "white";
    document.getElementById("events1").style.color = "white";
    document.getElementById("projects1").style.color = "white";
    document.getElementById("team1").style.color = "white";
    document.getElementById("home1").style.borderColor = "#404040";
    document.getElementById("events1").style.borderColor = "#404040";
    document.getElementById("projects1").style.borderColor = "#404040";
    document.getElementById("team1").style.borderColor = "#404040";
    document.getElementById("reg1").style.borderColor = "#404040";
    document.getElementById("home1").style.borderColor = "#404040";
    document.getElementById("home1").style.boxShadow = " 0px 2px 5px white";
    document.getElementById("events1").style.boxShadow = " 0px 2px 5px white";
    document.getElementById("projects1").style.boxShadow = " 0px 2px 5px white";
    document.getElementById("team1").style.boxShadow = " 0px 2px 5px white";
    document.getElementById("reg1").style.boxShadow = " 0px 2px 5px white";
  
  
  
    document.getElementById("box1").style.boxShadow = "  3px 5px rgba(255,255,255,0.294)";
    document.getElementById('cardd1').style.backgroundColor=" #272626"; 
    document.getElementById("dddd1").style.color = "white";
    document.getElementById("cccc1").style.color = "white";

  
  
 
  
  }
  
  