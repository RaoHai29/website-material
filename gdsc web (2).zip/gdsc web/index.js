function myFunction() {
  document.getElementById('a').style.backgroundImage="url(images/yellowdark.png)"; 
  document.body.style.backgroundColor = "#404040";// specify the image path here
  document.getElementById('b').style.backgroundColor="#404040"; 
  document.getElementById('footer').style.backgroundColor="#404040"; 
  document.getElementById("c").src = "images/logo2.png";
  document.getElementById('d').style.color="white"; 
  document.getElementById('ai').style.backgroundColor="#404040"; 
  document.getElementById('wb').style.backgroundColor="#ebeaeab7";
  document.getElementById('wb').style.color="orangered";
  document.getElementById('g').style.backgroundColor="#404040"; 
  document.getElementById('en').style.backgroundImage="url(images/enn2.png)"; 
  document.getElementById("home").style.color = "white";
  document.getElementById("events").style.color = "white";
  document.getElementById("projects").style.color = "white";
  document.getElementById("team").style.color = "white";
  document.getElementById("home").style.borderColor = "#404040";
  document.getElementById("events").style.borderColor = "#404040";
  document.getElementById("projects").style.borderColor = "#404040";
  document.getElementById("team").style.borderColor = "#404040";
  document.getElementById("reg").style.borderColor = "#404040";
  document.getElementById("home").style.borderColor = "#404040";
  document.getElementById("home").style.boxShadow = " 0px 2px 5px white";
  document.getElementById("events").style.boxShadow = " 0px 2px 5px white";
  document.getElementById("projects").style.boxShadow = " 0px 2px 5px white";
  document.getElementById("team").style.boxShadow = " 0px 2px 5px white";
  document.getElementById("reg").style.boxShadow = " 0px 2px 5px white";



  document.getElementById("box").style.boxShadow = "  3px 5px rgba(255,255,255,0.294)";
  document.getElementById('cardd').style.backgroundColor=" #272626"; 
  document.getElementById('a').style.backgroundImage="url(images/yellowdark.png)"; 


  document.getElementById("aa").style.color = "white";
  document.getElementById("bb").style.color = "white";
  document.getElementById("cc").style.color = "white";
  document.getElementById("dd").style.color = "white";
  document.getElementById("aaa").style.color = "white";
  document.getElementById("bbb").style.color = "white";
  document.getElementById("ccc").style.color = "white";
  document.getElementById("ddd").style.color = "white";
  document.getElementById("aaaa").style.color = "white";
  document.getElementById("bbbb").style.color = "white";
  document.getElementById("cccc").style.color = "white";
  document.getElementById("dddd").style.color = "white";
  document.getElementById("aao").style.color = "white";
  document.getElementById("bbo").style.color = "white";
  document.getElementById("cco").style.color = "white";
  document.getElementById("ddo").style.color = "white";
  document.getElementById("aaao").style.color = "white";
  document.getElementById("bbbo").style.color = "white";
  document.getElementById("ccco").style.color = "white";
  document.getElementById("dddo").style.color = "white";
  document.getElementById("aaaao").style.color = "white";
  document.getElementById("bbbbo").style.color = "white";


}

